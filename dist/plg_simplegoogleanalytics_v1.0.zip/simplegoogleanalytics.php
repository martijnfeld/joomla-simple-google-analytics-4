<?php
/**
 * @package Simple Google Analytics for Joomla! 2.5 and Joomla! 3.0
 * @author Daniele De Santis http://www.danieledesantis.net
 * @copyright (C) 2015 - Daniele De Santis. All rights reserved
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/
defined ( '_JEXEC' ) or die ( 'Restricted access' );

jimport('joomla.plugin');

class plgSystemSimpleGoogleAnalytics extends JPlugin {
	
  public function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		$this->loadLanguage();
  }
  
  function onAfterRender() {
		$app = JFactory::getApplication();
		if (!$app->isAdmin()) {
			$params = $this->params;
			$tracking_id = $params->get('sga_analytics');
			$anonymize_ip = $params->get('sga_anonymous');
			if($tracking_id) {
				$analytics = "<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', '" . $tracking_id . "', 'auto');
ga('send', 'pageview');";
				if($anonymize_ip == 'yes') {
					$analytics .= "
ga('set', 'anonymizeIp', true);";
				}
				$analytics .= "
</script>\n";
			
				$body = JResponse::getBody();
				$body = preg_replace("/<\/head>/", $analytics . "</head>", $body); 
				JResponse::setBody($body);
				
				return;
			}
		}
  }
	
}
?>